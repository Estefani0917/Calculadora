display.setStatusBar(display.HiddenStatusBar)

-- ====== colores =====
local BG = {0.30, 0.45, 1.00}
local BLACK = {0,0,0}
local WHITE = {1,1,1}

-- ===== fondo =====
local bg = display.newRect(
    display.contentCenterX,
    display.contentCenterY,
    display.actualContentWidth,
    display.actualContentHeight
)
bg:setFillColor(unpack(BG))

-- ===== Safe Area =====
local safeTop    = display.safeScreenOriginY
local safeLeft   = display.safeScreenOriginX
local safeRight  = display.safeActualContentWidth + safeLeft
local safeBottom = display.safeActualContentHeight + safeTop

local safeW = safeRight - safeLeft
local safeH = safeBottom - safeTop

-- ===== Helpers UI =====
local function makeLabelLeft(text, x, y)
    local t = display.newText({
        text = text,
        x = x, y = y,
        font = native.systemFontBold,
        fontSize = 42
    })
    t.anchorX = 0
    t:setFillColor(unpack(WHITE))
    return t
end

local function makeLabelCenter(text, x, y, size)
    local t = display.newText({
        text = text,
        x = x, y = y,
        font = native.systemFontBold,
        fontSize = size or 46
    })
    t:setFillColor(unpack(WHITE))
    return t
end

local function makeInput(x, y, w, h)
    local border = display.newRect(x, y, w, h)
    border:setFillColor(1,1,1)
    border.strokeWidth = 4
    border:setStrokeColor(unpack(BLACK))

    local tf = native.newTextField(x, y, w - 12, h - 12)
    tf.inputType = "number"
    tf.hasBackground = false
    tf.align = "left"
    tf:setTextColor(0,0,0)

    return tf, border
end

local function makeButton(symbol, x, y, size, onTap)
    local r = display.newRect(x, y, size, size)
    r:setFillColor(unpack(BLACK))

    local txt = display.newText({
        text = symbol,
        x = x, y = y,
        font = native.systemFontBold,
        fontSize = 96
    })
    txt:setFillColor(unpack(WHITE))

    r:addEventListener("tap", function()
        onTap()
        return true
    end)

    return r, txt
end

-- ===== Helpers cálculo =====
local function toNumberOrNil(s)
    if not s or s == "" then return nil end
    s = string.gsub(s,",", ".")
    return tonumber(s)
end

local function formatNumber(n)
    if n == math.floor(n) then
        return tostring(n)
    end
    return string.format("%.2f", n)
end

-- ===== Layout =====
local marginX = safeLeft + safeW * 0.12
local fieldW = safeW * 0.76
local fieldH = safeH * 0.08

local y1Label = safeTop + safeH * 0.15
local y1Field = safeTop + safeH * 0.23

local y2Label = safeTop + safeH * 0.33
local y2Field = safeTop + safeH * 0.41

local yResTitle = safeTop + safeH * 0.55
local yResValue = safeTop + safeH * 0.62

-- ===== Inputs =====
makeLabelLeft("Numero 1", marginX, y1Label)
local tf1 = makeInput(display.contentCenterX, y1Field, fieldW, fieldH)

makeLabelLeft("Numero 2", marginX, y2Label)
local tf2 = makeInput(display.contentCenterX, y2Field, fieldW, fieldH)

makeLabelCenter("Resultado", display.contentCenterX, yResTitle, 46)

local resValue = display.newText({
    text = "",
    x = display.contentCenterX,
    y = yResValue,
    font = native.systemFontBold,
    fontSize = 40
})
resValue:setFillColor(unpack(WHITE))

-- ===== Operaciones =====
local function operate(op)

    native.setKeyboardFocus(nil)

    local a = toNumberOrNil(tf1.text)
    local b = toNumberOrNil(tf2.text)

    if not a or not b then
        resValue.text = ""
        native.showAlert("Faltan datos", "Escribe Numero 1 y Numero 2.", {"OK"})
        return
    end

    local r

    if op == "+" then
        r = a + b
    elseif op == "-" then
        r = a - b
    elseif op == "x" then
        r = a * b
    elseif op == "/" then
        if b == 0 then
            native.showAlert("Error", "No se puede dividir entre 0.", {"OK"})
            return
        end
        r = a / b
    end

    resValue.text = formatNumber(r)
end

-- ===== Función Limpiar =====
local function limpiar()
    native.setKeyboardFocus(nil)
    tf1.text = ""
    tf2.text = ""
    resValue.text = ""
end

-- ===== Botones Operaciones =====
local btnSize = math.min(safeW, safeH) * 0.20
local gapX = safeW * 0.18
local gapY = safeH * 0.12

local centerX = display.contentCenterX
local baseY = safeTop + safeH * 0.74

local leftX = centerX - gapX
local rightX = centerX + gapX

local topY = baseY
local bottomY = baseY + gapY

makeButton("+", leftX,  topY,     btnSize, function() operate("+") end)
makeButton("-", rightX, topY,     btnSize, function() operate("-") end)
makeButton("x", leftX,  bottomY,  btnSize, function() operate("x") end)
makeButton("/", rightX, bottomY,  btnSize, function() operate("/") end)

-- ===== Botón Limpiar =====
local limpiarY = bottomY + gapY * 1.2

local limpiarBtn = display.newRoundedRect(
    display.contentCenterX,
    limpiarY,
    btnSize * 2.2,
    btnSize * 0.8,
    20
)
limpiarBtn:setFillColor(0.1, 0.7, 0.2)

local limpiarTxt = display.newText({
    text = "LIMPIAR",
    x = display.contentCenterX,
    y = limpiarY,
    font = native.systemFontBold,
    fontSize = 42
})
limpiarTxt:setFillColor(1,1,1)

limpiarBtn:addEventListener("tap", function()
    limpiar()
    return true
end)

-- ===== UX =====
tf1:addEventListener("userInput", function(e)
    if e.phase == "submitted" then
        native.setKeyboardFocus(tf2)
    end
end)

tf2:addEventListener("userInput", function(e)
    if e.phase == "submitted" then
        native.setKeyboardFocus(nil)
    end
end)

bg:addEventListener("tap", function()
    native.setKeyboardFocus(nil)
    return true
end)